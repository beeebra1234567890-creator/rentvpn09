package com.example.wgclient

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnController.init(applicationContext)
        setContent { RentVpnApp() }
    }
}

private data class Traffic(
    val up: Long = 0, val down: Long = 0,
    val upTotal: Long = 0, val downTotal: Long = 0,
    val history: List<Long> = emptyList(),
)

@Composable
private fun RentVpnApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    val state by VpnController.state.collectAsState()
    val error by VpnController.error.collectAsState()
    val connectedAt by VpnController.connectedAt.collectAsState()

    var servers by remember { mutableStateOf(ServerStore.load(context)) }
    var selected by remember { mutableIntStateOf(ServerStore.loadSelected(context, servers)) }
    var subUrl by remember { mutableStateOf(ServerStore.loadSubUrl(context)) }
    var input by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val pings = remember { mutableStateMapOf<String, Int>() } // raw -> мс, -1 = нет ответа
    var traffic by remember { mutableStateOf(Traffic()) }
    var elapsed by remember { mutableLongStateOf(0L) }

    val server = servers.getOrNull(selected)?.takeIf { it.supported }

    // ---- служебные эффекты ----
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(error) {
        error?.let { message = it; VpnController.clearError() }
    }
    LaunchedEffect(servers) {
        servers.filter { (it.protocol == "vless" || it.protocol == "http") && it.supported }.forEach { s ->
            launch { pings[s.raw] = ServerStore.ping(s) ?: -1 }
        }
    }
    LaunchedEffect(state, connectedAt) {
        if (state != VpnState.CONNECTED) { elapsed = 0; return@LaunchedEffect }
        while (true) {
            elapsed = (SystemClock.elapsedRealtime() - connectedAt) / 1000
            delay(500)
        }
    }
    LaunchedEffect(state) {
        if (state != VpnState.CONNECTED) { traffic = Traffic(); return@LaunchedEffect }
        val uid = Process.myUid()
        fun rx() = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
        fun tx() = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
        val baseRx = rx(); val baseTx = tx()
        var lastRx = baseRx; var lastTx = baseTx
        while (true) {
            delay(1000)
            val r = rx(); val t = tx()
            val down = (r - lastRx).coerceAtLeast(0); val up = (t - lastTx).coerceAtLeast(0)
            lastRx = r; lastTx = t
            traffic = Traffic(up, down, t - baseTx, r - baseRx, (traffic.history + down).takeLast(60))
        }
    }

    // ---- действия ----
    fun connectNow() {
        val s = server ?: return
        ServerStore.saveSelected(context, s)
        VpnController.connect(context, s)
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) connectNow() else message = "Разрешение Android VPN не выдано"
    }

    fun toggle() {
        if (state != VpnState.DISCONNECTED) { VpnController.disconnect(context); return }
        if (server == null) { message = "Сначала добавьте сервер"; tab = 2; return }
        val intent = VpnService.prepare(context)
        if (intent != null) permissionLauncher.launch(intent) else connectNow()
    }

    fun applyServers(list: List<Server>, replace: Boolean) {
        if (list.isEmpty()) { message = "Не удалось распознать серверы"; return }
        val prevRaw = server?.raw
        val merged = if (replace) list else (servers + list).distinctBy { it.raw }
        servers = merged
        ServerStore.save(context, merged)
        var idx = merged.indexOfFirst { it.raw == prevRaw && it.supported }
        if (idx < 0) idx = merged.indexOfFirst { it.supported }
        selected = idx
        ServerStore.saveSelected(context, merged.getOrNull(idx))
        message = "Серверов: ${list.size}, доступно: ${list.count { it.supported }}"
    }

    fun fetchSubscription(url: String) {
        scope.launch {
            busy = true
            runCatching { ServerStore.fetchText(context, url) }
                .onSuccess {
                    subUrl = ServerStore.normalizeUrl(url)
                    ServerStore.saveSubUrl(context, subUrl)
                    applyServers(ServerStore.parse(it), replace = true)
                }
                .onFailure { message = "Не удалось загрузить: ${it.message ?: "ошибка сети"}" }
            busy = false
        }
    }

    fun addInput(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (ServerStore.isSubscriptionUrl(t)) fetchSubscription(t)
        else { applyServers(ServerStore.parse(t), replace = false); input = "" }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching { readText(context, uri) }
            .onSuccess { applyServers(ServerStore.parse(it), replace = false) }
            .onFailure { message = "Не удалось прочитать файл" }
    }



    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, onPrimary = Color.White, background = Bg, surface = Surface1,
            onSurface = Color.White, onBackground = Color.White, outline = LineC
        )
    ) {
        // «Серверы» (tab 2) открываются с главной или из настроек, в нижней панели подсвечена «Главная»
        val navSelected = when (tab) { 1 -> 1; 3 -> 2; else -> 0 }
        BackHandler(enabled = tab != 0) { tab = 0 }

        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        state = state, server = server, ping = server?.let { pings[it.raw] },
                        traffic = traffic, elapsed = elapsed, message = message,
                        onToggle = { toggle() }, onServers = { tab = 2 }, onSettings = { tab = 3 }
                    )
                    1 -> SpeedScreen(state, traffic)
                    2 -> ServerScreen(
                        servers = servers, selected = selected, pings = pings, input = input,
                        subUrl = subUrl, message = message, busy = busy,
                        onBack = { tab = 0 },
                        onInput = { input = it },
                        onAdd = { addInput(input) },
                        onFile = { filePicker.launch(arrayOf("*/*")) },
                        onPaste = { clipboard.getText()?.text?.let { addInput(it) } ?: run { message = "Буфер обмена пуст" } },
                        onRefresh = { fetchSubscription(subUrl) },
                        onPick = { i ->
                            val s = servers[i]
                            if (!s.supported) message = "${s.name}: ${s.unsupportedReason}"
                            else {
                                if (state != VpnState.DISCONNECTED) VpnController.disconnect(context)
                                selected = i; ServerStore.saveSelected(context, s); message = "Выбран: ${s.name}"
                            }
                        },
                        onDelete = { i ->
                            val next = servers.filterIndexed { j, _ -> j != i }
                            val keepRaw = server?.raw
                            servers = next; ServerStore.save(context, next)
                            selected = next.indexOfFirst { it.raw == keepRaw && it.supported }.let { k ->
                                if (k >= 0) k else next.indexOfFirst { it.supported }
                            }
                            ServerStore.saveSelected(context, next.getOrNull(selected))
                        }
                    )
                    else -> SettingsScreen(
                        onServers = { tab = 2 },
                        onClear = {
                            if (state != VpnState.DISCONNECTED) VpnController.disconnect(context)
                            servers = emptyList(); selected = -1; subUrl = ""; pings.clear()
                            ServerStore.clear(context)
                            message = "Локальные данные удалены"
                        }
                    )
                }
            }
            BottomNav(navSelected) { tab = when (it) { 0 -> 0; 1 -> 1; else -> 3 } }
        }
    }
}

// ======================= HOME =======================

@Composable
private fun HomeScreen(
    state: VpnState, server: Server?, ping: Int?, traffic: Traffic, elapsed: Long, message: String,
    onToggle: () -> Unit, onServers: () -> Unit, onSettings: () -> Unit,
) {
    val connected = state == VpnState.CONNECTED
    val side = Modifier.padding(horizontal = 17.dp)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // шапка: логотип, название, настройки
        Row(side.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            ShieldLockIcon(Modifier.size(46.dp))
            Spacer(Modifier.width(14.dp))
            Text("VPN", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).panel(22.dp).clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) { GearIcon(Color(0xFFCFCFDA), Modifier.size(22.dp)) }
        }

        // карта мира + кнопка питания
        Box(Modifier.fillMaxWidth().height(292.dp)) {
            WorldMap(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            PowerButton(state, onToggle, Modifier.align(Alignment.TopCenter).offset(y = 104.dp))
        }

        // статус
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                when (state) {
                    VpnState.DISCONNECTED -> "Не подключено"
                    VpnState.CONNECTING -> "Подключение…"
                    VpnState.CONNECTED -> "Подключено"
                },
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            if (connected) {
                Text(formatTime(elapsed), color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text("Ваше соединение защищено", color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
            } else {
                Text(
                    if (state == VpnState.CONNECTING) "Устанавливаем защищённое соединение…"
                    else "Подключитесь, чтобы защитить своё соединение",
                    color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        ConnectButton(state, onToggle, Modifier.align(Alignment.CenterHorizontally).fillMaxWidth(0.72f))
        Spacer(Modifier.height(18.dp))

        if (message.isNotBlank()) {
            val bad = message.contains("Не удалось") || message.contains("Ошибка") || message.contains("не поддерж") ||
                message.contains("Некорректн") || message.contains("не выдано") || message.contains("Сначала")
            Text(
                message, color = if (bad) Bad else Accent, fontSize = 12.sp,
                modifier = side.fillMaxWidth().padding(bottom = 10.dp), maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }

        ServerCard(server, onServers, side)
        Spacer(Modifier.height(10.dp))

        // пинг и скорость
        val p = ping?.takeIf { it >= 0 }
        val (dv, du) = if (connected) formatSpeed(traffic.down) else ("—" to "")
        val (uv, uu) = if (connected) formatSpeed(traffic.up) else ("—" to "")
        Row(side.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Пинг", if (p != null) "$p" else "—", if (p != null) "мс" else "", Modifier.weight(1f)) {
                BoltIcon(Accent, Modifier.size(22.dp))
            }
            StatCard("Скорость", dv, du, Modifier.weight(1f)) {
                ArrowIcon(true, Accent, Modifier.size(22.dp))
            }
            StatCard("Скорость", uv, uu, Modifier.weight(1f)) {
                ArrowIcon(false, Accent, Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(10.dp))

        // плашка безопасности
        Row(
            side.fillMaxWidth().panel(20.dp).clickable(onClick = onSettings).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShieldCheckIcon(Color(0xFF9087D6), Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Text("Ваши данные в безопасности", color = Color(0xFFE4E4EC), fontSize = 15.sp, modifier = Modifier.weight(1f))
            ChevronIcon(false, Muted, Modifier.size(20.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ConnectButton(state: VpnState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    val idle = state == VpnState.DISCONNECTED
    val bg = if (idle) Brush.horizontalGradient(listOf(Color(0xFF7440F4), Color(0xFF4B25B8)))
    else Brush.horizontalGradient(listOf(Color(0xFF26262E), Color(0xFF1B1B22)))
    Row(
        modifier.height(54.dp).clip(shape).background(bg)
            .border(1.dp, if (idle) Color(0x33FFFFFF) else LineC, shape)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (state) {
            VpnState.DISCONNECTED -> { PlayIcon(Color.White, Modifier.size(20.dp)); Spacer(Modifier.width(12.dp)) }
            VpnState.CONNECTED -> { StopIcon(Color.White, Modifier.size(20.dp)); Spacer(Modifier.width(12.dp)) }
            VpnState.CONNECTING -> {}
        }
        Text(
            when (state) {
                VpnState.DISCONNECTED -> "Подключиться"
                VpnState.CONNECTING -> "Подключение…"
                VpnState.CONNECTED -> "Отключить"
            },
            color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun ServerCard(server: Server?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().panel(24.dp).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (server == null) {
            Text("Сервер не выбран — нажмите, чтобы добавить", color = Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
        } else {
            FlagBubble(server.name)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Сервер", color = Muted, fontSize = 12.sp)
                Text(
                    displayName(server.name), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        ChevronIcon(true, Muted, Modifier.size(24.dp))
    }
}

@Composable
private fun StatCard(
    label: String, value: String, unit: String, modifier: Modifier = Modifier,
    icon: @Composable () -> Unit,
) {
    Row(
        modifier.panel(20.dp).padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, color = Muted, fontSize = 12.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                if (unit.isNotEmpty()) {
                    Spacer(Modifier.width(2.dp))
                    Text(unit, color = Muted, fontSize = 9.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(bottom = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun FlagBubble(name: String) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) {
        Text(flagOf(name) ?: "🌐", fontSize = 20.sp)
    }
}

// ======================= STATISTICS =======================

@Composable
private fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
private fun SpeedScreen(state: VpnState, t: Traffic) {
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenTitle("Статистика")
        if (state != VpnState.CONNECTED) {
            Text("Подключитесь к серверу, чтобы увидеть статистику.", color = Muted, fontSize = 14.sp)
            return@Column
        }
        val (dv, du) = formatSpeed(t.down)
        Card2 {
            Text("Загрузка", color = Muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(dv, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text(du, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
            Canvas(Modifier.fillMaxWidth().height(110.dp)) { sparkline(t.history, Accent) }
        }
        val (uv, uu) = formatSpeed(t.up)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card2(Modifier.weight(1f)) {
                Text("Отдача", color = Muted, fontSize = 12.sp)
                Text("$uv $uu", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            Card2(Modifier.weight(1f)) {
                Text("За сессию", color = Muted, fontSize = 12.sp)
                Text("↓ ${formatBytes(t.downTotal)}", color = Color.White, fontSize = 15.sp)
                Text("↑ ${formatBytes(t.upTotal)}", color = Color.White, fontSize = 15.sp)
            }
        }
        Text("Показан трафик приложения до сервера (с учётом шифрования).", color = Muted, fontSize = 11.sp)
    }
}

// ======================= SERVERS =======================

@Composable
private fun ServerScreen(
    servers: List<Server>, selected: Int, pings: Map<String, Int>, input: String, subUrl: String,
    message: String, busy: Boolean,
    onBack: () -> Unit,
    onInput: (String) -> Unit, onAdd: () -> Unit, onFile: () -> Unit, onPaste: () -> Unit,
    onRefresh: () -> Unit, onPick: (Int) -> Unit, onDelete: (Int) -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 17.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).panel(20.dp).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { ChevronIcon(false, Color(0xFFCFCFDA), Modifier.size(20.dp).rotate(180f)) }
            Spacer(Modifier.width(12.dp))
            ScreenTitle("Серверы")
        }

        OutlinedTextField(
            value = input, onValueChange = onInput, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 5,
            label = { Text("Подписка (https://), vless://, http://user:pass@host:port или WireGuard") },
            colors = fieldColors(),
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            shape = RoundedCornerShape(18.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onAdd, enabled = input.isNotBlank() && !busy, modifier = Modifier.weight(1.3f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Violet, contentColor = Color.White,
                    disabledContainerColor = Surface2, disabledContentColor = Muted
                ),
                shape = RoundedCornerShape(16.dp)
            ) { Text(if (busy) "Загрузка…" else "Добавить", fontWeight = FontWeight.SemiBold) }
            OutlinedButton(onClick = onPaste, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Text("Из буфера", color = Accent) }
            OutlinedButton(onClick = onFile, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Text("Файл", color = Accent) }
        }
        if (subUrl.isNotBlank()) {
            OutlinedButton(onClick = onRefresh, enabled = !busy, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Text("Обновить подписку", color = Accent)
            }
        }
        if (message.isNotBlank()) Text(message, color = Muted, fontSize = 12.sp)

        if (servers.isNotEmpty()) {
            Text("СПИСОК (${servers.size})", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
            servers.forEachIndexed { i, s ->
                val isSel = i == selected
                val shape = RoundedCornerShape(22.dp)
                Row(
                    Modifier.fillMaxWidth().clip(shape)
                        .background(if (isSel) Surface2 else Surface1)
                        .border(1.dp, if (isSel) Accent.copy(alpha = .7f) else LineC, shape)
                        .clickable { onPick(i) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FlagBubble(s.name)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            displayName(s.name), color = if (s.supported) Color.White else Muted,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            s.protocol.uppercase() + if (s.supported) "" else " · ${s.unsupportedReason}",
                            color = if (s.supported) Muted else Bad.copy(alpha = .8f), fontSize = 11.sp, maxLines = 2
                        )
                    }
                    val p = pings[s.raw]?.takeIf { it >= 0 }
                    if ((s.protocol == "vless" || s.protocol == "http") && s.supported) {
                        PingBars(p, Modifier.size(width = 22.dp, height = 13.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (p != null) "$p" else "—", color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(8.dp))
                    }
                    if (isSel) Text("✓", color = Accent, fontSize = 18.sp)
                    Box(Modifier.size(34.dp).clip(CircleShape).clickable { onDelete(i) }, contentAlignment = Alignment.Center) {
                        Text("✕", color = Muted, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

// ======================= SETTINGS =======================

@Composable
private fun SettingsScreen(onServers: () -> Unit, onClear: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 17.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Настройки")
        Row(
            Modifier.fillMaxWidth().panel(22.dp).clickable(onClick = onServers).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Серверы и подписка", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Добавить, выбрать и обновить серверы", color = Muted, fontSize = 12.sp)
            }
            ChevronIcon(false, Muted, Modifier.size(22.dp))
        }
        InfoRow("Приложение", "RENT VPN · версия 1.2")
        InfoRow("VLESS", "TCP · WebSocket · gRPC · HTTPUpgrade · XHTTP\nTLS · Reality · xtls-rprx-vision")
        InfoRow("HTTP / HTTPS", "http://user:pass@host:port · https://user:pass@host:port (TLS до прокси)\nUDP через HTTP-прокси не передаётся")
        InfoRow("WireGuard", "Импорт .conf, вставка из буфера")
        InfoRow("Хранение", "Серверы и подписка — локально на устройстве")
        Spacer(Modifier.height(4.dp))
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Text("Удалить сохранённые данные", color = Bad)
        }
    }
}

@Composable
private fun InfoRow(title: String, value: String) {
    Card2 {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(value, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().panel(22.dp).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp), content = content
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Accent, unfocusedBorderColor = LineC,
    focusedLabelColor = Accent, unfocusedLabelColor = Muted, cursorColor = Accent
)

// ======================= NAV =======================

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("Главная", "Статистика", "Настройки")
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF0D0D11))
            .border(1.dp, LineC, shape)
            .navigationBarsPadding().padding(top = 10.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, label ->
            val on = i == selected
            Column(
                Modifier.weight(1f).clickable(remember { MutableInteractionSource() }, null) { onSelect(i) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NavIcon(i, if (on) Accent else Color(0xFF6E6E7A), Modifier.size(28.dp))
                Spacer(Modifier.height(4.dp))
                Text(label, color = if (on) Accent else Color(0xFF8A8A96), fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(34.dp).height(3.dp).clip(CircleShape).background(if (on) Accent else Color.Transparent))
            }
        }
    }
}

// ======================= helpers =======================

private fun formatTime(sec: Long): String = "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)

private fun formatSpeed(bps: Long): Pair<String, String> = when {
    bps >= 1_000_000 -> "%.1f".format(bps / 1_000_000.0) to "МБ/с"
    else -> "%d".format(bps / 1000) to "КБ/с"
}

private fun formatBytes(b: Long): String = when {
    b >= 1_000_000_000 -> "%.2f ГБ".format(b / 1e9)
    b >= 1_000_000 -> "%.1f МБ".format(b / 1e6)
    else -> "%d КБ".format(b / 1000)
}

/** Эмодзи-флаг в начале названия сервера (пара региональных индикаторов), если есть. */
private fun flagOf(name: String): String? {
    if (name.length < 4) return null
    val a = name.codePointAt(0)
    val b = name.codePointAt(Character.charCount(a))
    val isRi = { c: Int -> c in 0x1F1E6..0x1F1FF }
    return if (isRi(a) && isRi(b)) name.substring(0, Character.charCount(a) + Character.charCount(b)) else null
}

private fun displayName(name: String): String = flagOf(name)?.let { name.removePrefix(it).trim() } ?: name

private fun readText(context: Context, uri: Uri): String =
    context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
