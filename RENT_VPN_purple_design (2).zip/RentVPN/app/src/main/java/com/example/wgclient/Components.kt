package com.example.wgclient

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.ln
import kotlin.math.tan

// ---------- Палитра (почти чёрный фон + фиолетовый акцент) ----------
val Bg = Color(0xFF08080B)
val Violet = Color(0xFF7B3FF2)
val VioletDeep = Color(0xFF4A25B5)
val Accent = Color(0xFF9B6BFF)
val Surface1 = Color(0xFF121216)
val Surface2 = Color(0xFF1B1B21)
val LineC = Color(0xFF24242B)
val Muted = Color(0xFF8E8E9A)
val Good = Color(0xFF3DDC5A)
val Warn = Color(0xFFFFC857)
val Bad = Color(0xFFFF5C6C)

/** Тёмная карточка с тонкой светлой обводкой сверху (как на макете). */
fun Modifier.panel(radius: Dp = 22.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color(0xFF16161B), Color(0xFF0E0E12))))
        .border(1.dp, Brush.verticalGradient(listOf(Color(0xFF2B2B33), Color(0xFF18181D))), shape)
}

// ---------- Карта мира ----------
// Размеры и проекция совпадают с res/drawable/world_map.xml (Меркатор, 75°N … 56°S).
private const val MAP_ASPECT = 3600f / 1841f
private const val MAP_TOP_LAT = 75.0
private const val MAP_BOTTOM_LAT = -56.0

private fun mercY(lat: Double): Double = ln(tan(PI / 4 + Math.toRadians(lat) / 2))

/** Долгота/широта → доли (0..1) от ширины и высоты карты. */
private fun mapPoint(lon: Double, lat: Double): Offset {
    val top = mercY(MAP_TOP_LAT)
    val bottom = mercY(MAP_BOTTOM_LAT)
    val x = ((lon + 180.0) / 360.0).toFloat()
    val y = ((top - mercY(lat)) / (top - bottom)).toFloat()
    return Offset(x, y)
}

private val mapCities = listOf(
    mapPoint(-74.0, 40.7),   // Нью-Йорк
    mapPoint(-118.2, 34.0),  // Лос-Анджелес
    mapPoint(-46.6, -23.5),  // Сан-Паулу
    mapPoint(-0.1, 51.5),    // Лондон
    mapPoint(8.7, 50.1),     // Франкфурт
    mapPoint(37.6, 55.7),    // Москва
    mapPoint(55.3, 25.2),    // Дубай
    mapPoint(72.9, 19.1),    // Мумбаи
    mapPoint(103.8, 1.35),   // Сингапур
    mapPoint(114.2, 22.3),   // Гонконг
    mapPoint(139.7, 35.7),   // Токио
    mapPoint(151.2, -33.9),  // Сидней
)

@Composable
fun WorldMap(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "map")
    val pulse = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "mapPulse"
    )
    Box(modifier.aspectRatio(MAP_ASPECT)) {
        Image(
            painter = painterResource(R.drawable.world_map),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Canvas(Modifier.fillMaxSize()) {
            val a = pulse.value
            mapCities.forEachIndexed { i, p ->
                val c = Offset(p.x * size.width, p.y * size.height)
                val ph = if (i % 2 == 0) a else 1f - a
                drawCircle(Accent.copy(alpha = 0.08f + 0.14f * ph), radius = 7.dp.toPx(), center = c)
                drawCircle(Accent, radius = 2.2f.dp.toPx(), center = c)
            }
        }
        // растворяем края карты в фоне
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to Bg, 0.2f to Color.Transparent, 0.8f to Color.Transparent, 1f to Bg)
            )
        )
    }
}

// ---------- Кнопка питания ----------
@Composable
fun PowerButton(state: VpnState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "power")
    val spin = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "spin"
    )
    val pulse = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        modifier
            .size(180.dp)
            .clip(CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val connected = state == VpnState.CONNECTED
            val connecting = state == VpnState.CONNECTING
            val p = pulse.value

            // свечение
            val glow = when {
                connected -> 0.42f + 0.18f * p
                connecting -> 0.30f
                else -> 0.24f
            }
            drawCircle(
                Brush.radialGradient(listOf(Violet.copy(alpha = glow), Color.Transparent), center = c, radius = r),
                radius = r, center = c
            )
            // тонкое внешнее кольцо
            drawCircle(Color(0xFF2B2B33), radius = r * 0.9f, center = c, style = Stroke(1.dp.toPx()))
            if (connected) {
                drawCircle(
                    Accent.copy(alpha = 0.35f * (1f - p)),
                    radius = r * (0.74f + 0.16f * p), center = c, style = Stroke(1.5.dp.toPx())
                )
            }

            // тёмный диск
            val ri = r * 0.68f
            val discTop = if (connected) Color(0xFF241447) else Color(0xFF14121C)
            drawCircle(
                Brush.radialGradient(listOf(discTop, Color(0xFF07070A)), center = c, radius = ri),
                radius = ri, center = c
            )

            // фиолетовое кольцо
            val rw = 5.dp.toPx()
            val rr = ri - rw / 2f
            drawCircle(
                Brush.sweepGradient(listOf(Accent, Violet, VioletDeep, Violet, Accent), center = c),
                radius = rr, center = c, style = Stroke(rw)
            )
            drawCircle(
                Violet.copy(alpha = if (connected) 0.30f else 0.14f),
                radius = rr - rw * 1.2f, center = c, style = Stroke(rw * 1.6f)
            )

            // «бегущая» дуга при подключении
            if (connecting) {
                rotate(spin.value, c) {
                    drawArc(
                        Color.White.copy(alpha = 0.9f), startAngle = 0f, sweepAngle = 80f, useCenter = false,
                        topLeft = Offset(c.x - rr, c.y - rr), size = Size(rr * 2f, rr * 2f),
                        style = Stroke(rw, cap = StrokeCap.Round)
                    )
                }
            }
        }
        PowerIcon(Color.White, Modifier.size(40.dp))
    }
}

@Composable
fun PowerIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val stroke = Stroke(width = w * 0.085f, cap = StrokeCap.Round)
        drawArc(
            color, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(w * 0.17f, w * 0.2f), size = Size(w * 0.66f, w * 0.66f), style = stroke
        )
        drawLine(color, Offset(w * 0.5f, w * 0.08f), Offset(w * 0.5f, w * 0.46f), strokeWidth = stroke.width, cap = StrokeCap.Round)
    }
}

// ---------- Иконки ----------
private fun shieldPath(w: Float): Path = Path().apply {
    moveTo(w * .5f, w * .05f)
    lineTo(w * .9f, w * .2f)
    lineTo(w * .9f, w * .5f)
    cubicTo(w * .9f, w * .76f, w * .7f, w * .9f, w * .5f, w * .97f)
    cubicTo(w * .3f, w * .9f, w * .1f, w * .76f, w * .1f, w * .5f)
    lineTo(w * .1f, w * .2f)
    close()
}

/** Логотип: щит с замком. */
@Composable
fun ShieldLockIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val sh = shieldPath(w)
        drawPath(sh, Brush.verticalGradient(listOf(Violet.copy(alpha = .38f), VioletDeep.copy(alpha = .12f))))
        drawPath(sh, Brush.verticalGradient(listOf(Accent, Violet)), style = Stroke(w * .06f, join = StrokeJoin.Round))
        // дужка и корпус замка
        drawArc(
            Accent, 180f, 180f, false, Offset(w * .39f, w * .29f), Size(w * .22f, w * .3f),
            style = Stroke(w * .055f, cap = StrokeCap.Round)
        )
        drawRoundRect(Accent, Offset(w * .33f, w * .46f), Size(w * .34f, w * .26f), CornerRadius(w * .04f))
        drawCircle(Color(0xFF1A1033), w * .035f, Offset(w * .5f, w * .57f))
    }
}

@Composable
fun ShieldCheckIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawPath(shieldPath(w), color, style = Stroke(w * .08f, join = StrokeJoin.Round))
        val tick = Path().apply {
            moveTo(w * .32f, w * .5f)
            lineTo(w * .46f, w * .64f)
            lineTo(w * .7f, w * .38f)
        }
        drawPath(tick, color, style = Stroke(w * .08f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun GearIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawCircle(color, w * .27f, center, style = Stroke(w * .09f))
        drawCircle(color, w * .1f, center, style = Stroke(w * .08f))
        val tw = w * .13f
        for (i in 0 until 8) {
            rotate(i * 45f, center) {
                drawRoundRect(color, Offset(center.x - tw / 2f, center.y - w * .46f), Size(tw, w * .16f), CornerRadius(tw / 3f))
            }
        }
    }
}

/** Шеврон: вниз ([down] = true) или вправо. */
@Composable
fun ChevronIcon(down: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            if (down) {
                moveTo(w * .25f, w * .38f); lineTo(w * .5f, w * .63f); lineTo(w * .75f, w * .38f)
            } else {
                moveTo(w * .38f, w * .25f); lineTo(w * .63f, w * .5f); lineTo(w * .38f, w * .75f)
            }
        }
        drawPath(p, color, style = Stroke(w * .09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlayIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * .26f, w * .14f); lineTo(w * .86f, w * .5f); lineTo(w * .26f, w * .86f); close()
        }
        drawPath(p, color)
        drawPath(p, color, style = Stroke(w * .08f, join = StrokeJoin.Round))
    }
}

@Composable
fun StopIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawRoundRect(color, Offset(w * .22f, w * .22f), Size(w * .56f, w * .56f), CornerRadius(w * .1f))
    }
}

@Composable
fun BoltIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * .6f, w * .04f)
            lineTo(w * .2f, w * .56f)
            lineTo(w * .46f, w * .56f)
            lineTo(w * .38f, w * .96f)
            lineTo(w * .8f, w * .4f)
            lineTo(w * .54f, w * .4f)
            close()
        }
        drawPath(p, color)
        drawPath(p, color, style = Stroke(w * .05f, join = StrokeJoin.Round))
    }
}

/** Стрелка загрузки (вниз) или отдачи (вверх) с «лотком». */
@Composable
fun ArrowIcon(down: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * .09f
        drawLine(color, Offset(w * .18f, w * .88f), Offset(w * .82f, w * .88f), sw, StrokeCap.Round)
        val head = Path()
        if (down) {
            drawLine(color, Offset(w * .5f, w * .1f), Offset(w * .5f, w * .66f), sw, StrokeCap.Round)
            head.moveTo(w * .3f, w * .47f); head.lineTo(w * .5f, w * .67f); head.lineTo(w * .7f, w * .47f)
        } else {
            drawLine(color, Offset(w * .5f, w * .68f), Offset(w * .5f, w * .12f), sw, StrokeCap.Round)
            head.moveTo(w * .3f, w * .31f); head.lineTo(w * .5f, w * .11f); head.lineTo(w * .7f, w * .31f)
        }
        drawPath(head, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Иконки нижней навигации: 0 — главная, 1 — статистика, 2 — настройки. */
@Composable
fun NavIcon(kind: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        when (kind) {
            0 -> { // дом
                val p = Path().apply {
                    moveTo(w * .5f, w * .1f)
                    lineTo(w * .92f, w * .46f)
                    lineTo(w * .8f, w * .46f)
                    lineTo(w * .8f, w * .88f)
                    lineTo(w * .6f, w * .88f)
                    lineTo(w * .6f, w * .62f)
                    lineTo(w * .4f, w * .62f)
                    lineTo(w * .4f, w * .88f)
                    lineTo(w * .2f, w * .88f)
                    lineTo(w * .2f, w * .46f)
                    lineTo(w * .08f, w * .46f)
                    close()
                }
                drawPath(p, color)
                drawPath(p, color, style = Stroke(w * .06f, join = StrokeJoin.Round))
            }
            1 -> { // столбики
                val bw = w * .2f
                val r = CornerRadius(w * .05f)
                drawRoundRect(color, Offset(w * .12f, w * .56f), Size(bw, w * .34f), r)
                drawRoundRect(color, Offset(w * .4f, w * .36f), Size(bw, w * .54f), r)
                drawRoundRect(color, Offset(w * .68f, w * .12f), Size(bw, w * .78f), r)
            }
            else -> { // плитки
                val s = w * .34f
                val r = CornerRadius(w * .09f)
                drawRoundRect(color, Offset(w * .1f, w * .1f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .56f, w * .1f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .1f, w * .56f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .56f, w * .56f), Size(s, s), r)
            }
        }
    }
}

/** Вертикальные столбики качества связи. */
@Composable
fun PingBars(ping: Int?, modifier: Modifier = Modifier) {
    val level = when {
        ping == null -> 0
        ping < 120 -> 4
        ping < 250 -> 3
        ping < 450 -> 2
        else -> 1
    }
    val col = when (level) { 4, 3 -> Good; 2 -> Warn; 1 -> Bad; else -> Muted }
    Canvas(modifier) {
        val bw = size.width / 7f
        for (i in 0 until 4) {
            val h = size.height * (0.4f + 0.2f * i)
            drawRoundRect(
                if (i < level) col else Color(0xFF3A3A44),
                Offset(i * bw * 1.7f, size.height - h), Size(bw, h),
                CornerRadius(bw / 2)
            )
        }
    }
}

/** Заливка-«спарклайн» для экрана статистики. */
fun DrawScope.sparkline(values: List<Long>, color: Color) {
    if (values.size < 2) return
    val max = (values.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
    val step = size.width / (values.size - 1)
    val line = Path()
    val fill = Path()
    values.forEachIndexed { i, v ->
        val x = i * step
        val y = size.height - (v / max) * size.height * 0.9f - 2f
        if (i == 0) { line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y) } else { line.lineTo(x, y); fill.lineTo(x, y) }
    }
    fill.lineTo(size.width, size.height); fill.close()
    drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = .35f), Color.Transparent)))
    drawPath(line, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}
